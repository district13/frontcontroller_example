<? 
	class Collection_PostsCollection extends Collection_AbstractCollection {
	
		protected $_familyClass = "Post";

	}
	
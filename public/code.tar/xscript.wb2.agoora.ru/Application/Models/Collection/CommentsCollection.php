<? 
	class Collection_CommentsCollection extends Collection_AbstractCollection 
	{
		protected $_familyClass = "Comment";
	}
	
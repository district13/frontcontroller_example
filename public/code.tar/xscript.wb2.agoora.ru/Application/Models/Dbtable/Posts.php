<? 
	class Dbtable_Posts extends Dbtable_Abstract {
		protected $_name = "posts";
		
	}
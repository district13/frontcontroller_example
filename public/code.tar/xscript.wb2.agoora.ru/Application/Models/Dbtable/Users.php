<? 
	class Dbtable_Users extends Dbtable_Abstract {
		protected $_name = "users";
		
	}
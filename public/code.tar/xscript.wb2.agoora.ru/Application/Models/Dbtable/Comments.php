<? 
	class Dbtable_Comments extends Dbtable_Abstract {
		protected $_name = "comments";
	}
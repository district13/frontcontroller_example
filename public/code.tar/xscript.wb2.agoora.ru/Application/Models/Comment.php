<? 
	class Comment extends Model_Abstract 
	{
		public $id;
		public $text = '';
		public $create_datetime = '';
		public $user = null;
		public $post = null;
		
	}	
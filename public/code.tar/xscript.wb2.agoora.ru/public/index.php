<?
	define('APPLICATION_PATH', '../Application');


	require( "../Xscript/Controller/Front.php");
	Xscript_Controller_Front::run(APPLICATION_PATH . "/Config/application.ini");

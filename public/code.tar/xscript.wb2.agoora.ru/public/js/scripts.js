$(window).load(function () {
	init();
});

function init() {
	$("#addcomment").click(function(){
		var dataComment = $("#addcomment_form").serializeArray();
		$.post("/post/addcomment", dataComment, function(data){
			$("#comments").html(data);
			$("#comment_text").val("");
		});
	});
	
	$("#auth_button").click(function(){
		authClick();
	});
}

function authClick() {
	var dataAuth = $("#auth_form").serializeArray();
	$.post("/index/login", dataAuth, function(data){
		$("#user_block").html(data);
	});
}